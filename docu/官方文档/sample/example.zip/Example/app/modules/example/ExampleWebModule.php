<?php


Kurogo::includePackage('DateTime');

class ExampleWebModule extends WebModule{

  protected $id = 'example';
  protected $model;
  protected $detailsController;

  protected function initialize(){
    $this->detailsController = new DataObjectDetailsController($this);

    $feedData = $this->loadFeedData();
    $feed = current($feedData);
    $this->model = DataModel::factory('StackExchangeDataModel', $feed);
  }

  protected function linkForQuestion(StackExchangeQuestion $question){
    $link = array(
      'title'    => $question->getTitle(),
      'subtitle' => $question->getSubtitle(),
      'url'      => $this->buildBreadcrumbURL('question', array('id' => $question->getID())),
    );
    return $link;
  }

  protected function linkForAnswer(StackExchangeAnswer $answer){
    $link = array(
      'title'    => $answer->getOwner()->getName(),
      'subtitle' => $answer->getSubtitle(),
      'url'      => $this->buildBreadcrumbURL('answer', array('id' => $answer->getID())),
    );
    return $link;
  }

  protected function buildQuestionResultsList($items){
    $links = array();
    foreach ($items as $item) {
      $links[] = $this->linkForQuestion($item);
    }
    return $links;
  }

  protected function initializeForPage(){
    switch ($this->page) {
      case 'pane':
      case 'index':
        $this->model->setLimit(5);
        $questionItems = $this->model->getFeaturedQuestions();
        $questions = $this->buildQuestionResultsList($questionItems);
        
        $this->assign('recentQuestionsHeader', $this->getOptionalModuleVar("RECENT_QUESTIONS_HEADER"));
        $this->assign('recentQuestions', $questions);
        $this->assign('placeholder', $this->getOptionalModuleVar("SEARCH_PLACEHOLDER"));
        break;

      case 'search':
        if(!$searchTerms = trim($this->getArg('filter'))){
          $this->redirectTo('index');
        }

        $this->model->setLimit(20);
        $resultItems = $this->model->search($searchTerms);
        $results = $this->buildQuestionResultsList($resultItems);

        $this->assign('searchTerms', $searchTerms);
        $this->assign('results', $results);
        break;
      
      case 'question':
        if(!$id = $this->getArg('id')){
          $this->redirectTo('index');
        }

        $question = $this->model->getQuestion($id);

        $this->assign('questionTitle', $question->getTitle());
        $this->assign('author', $question->getOwner()->getName());
        $this->assign('created', $this->itemCreated($question->getAttribute('creation_date')));

        if($answerID = $question->getAttribute('acceptedAnswerId')){
          $answer = $this->model->getAnswer($answerID);
          $this->assign('answerBody', $answer->getAttribute('body'));
          $this->assign('answerAuthor', $answer->getOwner()->getName());
          $this->assign('answerCreated', $this->itemCreated($answer->getAttribute('creation_date')));
        }

        $allAnswersLink = array(
          'title' => $this->getOptionalModuleVar("ALL_ANSWERS"),
          'subtitle' => $this->getLocalizedString('ALL_ANSWERS_COUNT', $question->getAttribute('answer_count')),
          'url' => $this->buildBreadcrumbURL('answers', array('questionID' => $question->getID())),
        );
        $this->assign('allAnswersLink', array($allAnswersLink));

        $tabsData = $this->detailsController->formatTabs($question, $this->page);
        $this->enableTabs(array_keys($tabsData));
        $this->assign('tabsData',$tabsData);
        break;
      case 'answers':
        if(!$questionID = $this->getArg('questionID')){
          $this->redirectTo('index');
        }

        $this->model->setLimit(20);
        $answerItems = $this->model->getAnswersForQuestion($questionID);
        $answers = array();
        foreach ($answerItems as $item) {
          $answers[] = $this->linkForAnswer($item);
        }
        $this->assign('answers', $answers);
        break;
      case 'answer':
        if(!$id = $this->getArg('id')){
          $this->redirectTo('index');
        }

        $answer = $this->model->getAnswer($id);

        $this->assign('author', $answer->getOwner()->getName());
        $this->assign('created', $this->itemCreated($answer->getAttribute('creation_date')));
        $this->assign('answerBody', $answer->getAttribute('body'));

        break;
    }
  }

  protected function itemCreated($timestamp) {
    return DateFormatter::formatDate($timestamp, DateFormatter::SHORT_STYLE, DateFormatter::SHORT_STYLE);
  }
  
}
