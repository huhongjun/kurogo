<?php

interface StackExchangeDataInterface extends SearchDataRetriever {

  public function getFeaturedQuestions();
  public function getQuestions();
  public function getQuestion($id);
  public function getAnswersForQuestion($questionID);
  public function getAnswer($id);

}
