<?php

class StackExchangeDataRetriever extends URLDataRetriever implements StackExchangeDataInterface {
  
  protected $DEFAULT_PARSER_CLASS = 'StackExchangeDataParser';
  protected $site = 'stackoverflow';
  protected $apiURL = 'api.stackexchange.com';
  protected $version = '2.1';
  protected $apiKey;

  protected function init($args){
    parent::init($args);

    if($site = Kurogo::arrayVal($args, 'SITE_NAME')){
      $this->site = $site;
    }

    if($version = Kurogo::arrayVal($args, 'API_VERSION')){
      $this->version = $version;
    }

    if($apiKey = Kurogo::arrayVal($args, 'API_KEY')){
      $this->apiKey = $apiKey;
    }
  }

  protected function initRequest(){
    parent::initRequest();

    $this->addHeader('Accept-Encoding', 'deflate');
    $this->addParameter('site', $this->site);

    if ($limit = $this->getOption('limit')) {
      $this->addParameter('pagesize', $limit);
    }

    if($this->apiKey){
      $this->addParameter('key', $this->apiKey);
    }
  }

  public function getFeaturedQuestions(){
    $this->setOption('action', 'getFeaturedQuestions');
    $this->setBaseURL($this->getEndpoint() . 'questions/featured');
    $this->addParameter('sort', 'votes');
    return $this->getData();
  }

  public function getQuestions(){
    $this->setOption('action', 'getQuestions');
    $this->setBaseURL($this->getEndpoint() . 'questions');
    $this->addParameter('sort', 'votes');
    return $this->getData();
  }

  public function getQuestion($id){
    $this->setOption('action', 'getQuestion');
    $this->setBaseURL(sprintf("%s%s/%s", $this->getEndpoint(), 'questions', $id));
    # This adds the question.body filter
    $this->addParameter('filter', '!9hnGss2Cz');
    return $this->getData();
  }

  public function search($searchTerms, &$response=null){
    $this->setOption('action', 'search');
    $this->setBaseURL($this->getEndpoint() . 'search');
    $this->addParameter('intitle', $searchTerms);
    $this->addParameter('sort', 'votes');
    return $this->getData($response);
  }

  public function getAnswersForQuestion($questionID){
    $this->setOption('action', 'getAnswersForQuestion');
    $this->setBaseURL(sprintf("%s%s/%s/%s", $this->getEndpoint(), 'questions', $questionID, 'answers'));
    $this->addParameter('sort', 'votes');
    # Filter to add total and answer.body
    $this->addParameter('filter', '!9hnGsyXaB');
    return $this->getData();
  }

  public function getAnswer($id){
    # Clear cache because this is potentially the second
    # data request during the current request.
    $this->clearInternalCache();
    $this->setOption('action', 'getAnswer');
    $this->setBaseURL(sprintf("%s%s/%s", $this->getEndpoint(), 'answers', $id));
    # This adds the answer.body filter
    $this->addParameter('filter', '!9hnGsyXaB');
    return $this->getData();
  }

  protected function getEndpoint(){
    return sprintf('http://%s/%s/', $this->apiURL, $this->version);
  }

}
