<?php

class StackExchangeDataParser extends JSONDataParser {
  
  public function parseData($data){
    $data = parent::parseData(gzinflate($data));

    $action = $this->getOption('action');
    switch ($action) {
      case 'getFeaturedQuestions':
      case 'getQuestions':
      case 'search':
        $questions = array();
        foreach ($data['items'] as $item) {
          $questions[] = $this->parseQuestion($item);
        }
        return $questions;
        break;
      case 'getQuestion':
        $item = current($data['items']);
        return $this->parseQuestion($item);
        break;
      case 'getAnswersForQuestion':
        $answers = array();
        foreach ($data['items'] as $item) {
          $answers[] = $this->parseAnswer($item);
        }
        return $answers;
        break;
      case 'getAnswer':
        $item = current($data['items']);
        return $this->parseAnswer($item);
        break;
    }
  }

  protected function parseQuestion($data){
    $question = new StackExchangeQuestion();
    $question->setID($data['question_id']);
    $question->setTitle($data['title']);
    $question->setOwner($this->parseOwner($data['owner']));

    $question->setAttribute('score', $data['score']);
    $question->setAttribute('answer_count', $data['answer_count']);
    # Use arrayVal here because we may not always have a body
    $question->setAttribute('body', Kurogo::arrayVal($data, 'body'));
    $question->setAttribute('is_answered', $data['is_answered']);
    $question->setAttribute('tags', $data['tags']);
    $question->setAttribute('creation_date', $data['creation_date']);
    $question->setAttribute('viewCount', $data['view_count']);
    $question->setAttribute('acceptedAnswerId', Kurogo::arrayVal($data, 'accepted_answer_id'));
    return $question;
  }

  protected function parseAnswer($data){
    $answer = new StackExchangeAnswer();
    $answer->setID($data['answer_id']);
    $answer->setAttribute('score', $data['score']);
    $answer->setOwner($this->parseOwner($data['owner']));
    $answer->setAttribute('body', Kurogo::arrayVal($data, 'body'));
    $answer->setAttribute('is_accepted', $data['is_accepted']);
    $answer->setAttribute('creation_date', $data['creation_date']);
    return $answer;
  }

  protected function parseOwner($data){
    $owner = new StackExchangePerson();
    $owner->setID(Kurogo::arrayVal($data, 'user_id'));
    $owner->setName($data['display_name']);
    $owner->setAttribute('reputation', Kurogo::arrayVal($data, 'reputation'));
    $owner->setAttribute('profile_image', Kurogo::arrayVal($data, 'profile_image'));
    return $owner;
  }

}
