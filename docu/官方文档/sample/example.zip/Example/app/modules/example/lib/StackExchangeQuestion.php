<?php

class StackExchangeQuestion extends KurogoDataObject {

  protected $owner;

  public function getSubtitle(){
    return sprintf("Score: %s | Answers: %s", $this->getAttribute('score'), $this->getAttribute('answer_count'));
  }

  public function getOwner(){
    return $this->owner;
  }

  public function setOwner(StackExchangePerson $owner){
    $this->owner = $owner;
    return $this;
  }
}
