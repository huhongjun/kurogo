<?php

class StackExchangeAnswer extends KurogoDataObject {

  protected $owner;

  public function getSubtitle(){
    return sprintf("Score: %s", $this->getAttribute('score'));
  }

  public function getOwner(){
    return $this->owner;
  }

  public function setOwner(StackExchangePerson $owner){
    $this->owner = $owner;
    return $this;
  }
}
