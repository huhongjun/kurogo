<?php

class StackExchangeDataModel extends DataModel{

  protected $DEFAULT_RETRIEVER_CLASS = 'StackExchangeDataRetriever';
  protected $RETRIEVER_INTERFACE = 'StackExchangeDataInterface';

  public function setLimit($limit) {
    $this->setOption('limit', $limit);
  }
}
